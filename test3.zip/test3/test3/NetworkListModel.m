//
//  NetworkListModel.m
//  test3
//
//  Created by ckl@pmm on 16/9/23.
//  Copyright © 2016年 pronetway. All rights reserved.
//

#import "NetworkListModel.h"

@implementation NetworkListModel


- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
    
}
+ (NetworkListModel *)setUpModelWithDictionary:(NSDictionary *)dictionary {
    
    NetworkListModel *model = [[NetworkListModel alloc]init];
    [model setValuesForKeysWithDictionary:dictionary];
    return model;
    
}

@end
