//
//  ViewController.m
//  test3
//
//  Created by ckl@pmm on 16/9/23.
//  Copyright © 2016年 pronetway. All rights reserved.
//

#import "ViewController.h"
#import <NetworkExtension/NetworkExtension.h>
#import "NetworkListModel.h"

@interface ViewController ()
@property (nonatomic ,strong)NSMutableArray *networkListArr;
@end

@implementation ViewController

#pragma mark -- 懒加载 --
-(NSMutableArray*)networkListArr{

    if (!_networkListArr) {
        _networkListArr = [[NSMutableArray alloc]init];
    }
    return _networkListArr;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
  //  [self scanf];
    [self scanWifiInfos];
    // Do any additional setup after loading the view, typically from a nib.
}

-(void)scanf{

    NSMutableDictionary* options = [[NSMutableDictionary alloc] init];
    [options setObject:@"新网程" forKey:kNEHotspotHelperOptionDisplayName];
    
    dispatch_queue_t queue = dispatch_queue_create("com.pronetway.GetwifiList", NULL);
    BOOL returnType = [NEHotspotHelper registerWithOptions:options queue:queue handler: ^(NEHotspotHelperCommand * cmd) {
        NEHotspotNetwork* network;
        NSLog(@"COMMAND TYPE:   %ld", (long)cmd.commandType);
        [cmd createResponse:kNEHotspotHelperResultAuthenticationRequired];
        if (cmd.commandType == kNEHotspotHelperCommandTypeEvaluate || cmd.commandType ==kNEHotspotHelperCommandTypeFilterScanList) {
            NSLog(@"WIFILIST:   %@", cmd.networkList);
            for (network  in cmd.networkList) {
               // NSLog(@"COMMAND TYPE After:   %ld", (long)cmd.commandType);
                if ([network.SSID isEqualToString:@"ssid"]|| [network.SSID isEqualToString:@"@ProWIFI"]) {
                    
                    double signalStrength = network.signalStrength;
                    NSLog(@"Signal Strength: %f", signalStrength);
                    [network setConfidence:kNEHotspotHelperConfidenceHigh];
                    [network setPassword:@"password"];
                    
                    NEHotspotHelperResponse *response = [cmd createResponse:kNEHotspotHelperResultSuccess];
                    NSLog(@"Response CMD %@", response);
                    
                    [response setNetworkList:@[network]];
                    [response setNetwork:network];
                    [response deliver];
                }
            }
        }
    }];
    NSLog(@"result :%d", returnType);
    NSArray *array = [NEHotspotHelper supportedNetworkInterfaces];
    NSLog(@"wifiArray:%@", array);
    NEHotspotNetwork *connectedNetwork = [array lastObject];
    NSLog(@"supported Network Interface: %@", connectedNetwork);
}


-(void)scanWifiInfos{
    NSLog(@"in wifi scan");
    NSMutableDictionary* options = [[NSMutableDictionary alloc] init];
    //NSMutableDictionary* infos = [[NSMutableDictionary alloc] init];
    
    [options setObject:@"meme" forKey:kNEHotspotHelperOptionDisplayName];
    
    dispatch_queue_t queue = dispatch_queue_create("LiyiZhan.WifiDemo", 0);
    
    BOOL returnType = [NEHotspotHelper registerWithOptions:options queue:queue handler:^(NEHotspotHelperCommand * cmd){
        NSLog(@"returnType is ---> %d",returnType);
        NSLog(@"in block");
        [cmd createResponse:kNEHotspotHelperResultAuthenticationRequired];
        if(cmd.commandType == kNEHotspotHelperCommandTypeEvaluate || cmd.commandType == kNEHotspotHelperCommandTypeFilterScanList){
            NSLog(@"bbbb = %lu",cmd.networkList.count);
            for(NEHotspotNetwork* network in cmd.networkList){
                
                if (_networkListArr.count<=cmd.networkList.count) {
                    if (network.SSID!= nil || ![network.SSID isEqualToString:@""]) {
                    NetworkListModel *model = [[NetworkListModel alloc]init];
                    model.ssid = network.SSID;
                    model.bssid = network.BSSID;
                    model.signalStrength = network.signalStrength;
                        NSLog(@"---ssid --- is %@",model.ssid);
                    [self.networkListArr addObject:model];
                }
            }else {
                
                NSLog(@"不做操作");
                }
//                NSString* ssid = network.SSID;
//                NSString* bssid = network.BSSID;
//                BOOL secure = network.secure;
//                BOOL autoJoined = network.autoJoined;
//                double signalStrength = network.signalStrength;
//                
//                NSLog(@"SSID:->%@\n BSSID:--->%@ \n SIGNAL:---->%f",ssid,bssid,signalStrength);
                
                
            }
        }
        NetworkListModel *model = _networkListArr[0];
        NSLog(@"数组里面第一个ssid 是 ---> %@ \n  数组的个数是--->%lu",model.ssid,(unsigned long)_networkListArr.count);
        
    }];
}

  

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
