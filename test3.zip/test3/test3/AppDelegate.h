//
//  AppDelegate.h
//  test3
//
//  Created by ckl@pmm on 16/9/23.
//  Copyright © 2016年 pronetway. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

