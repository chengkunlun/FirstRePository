//
//  NetworkListModel.h
//  test3
//
//  Created by ckl@pmm on 16/9/23.
//  Copyright © 2016年 pronetway. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NetworkListModel : NSObject
@property (nonatomic ,strong)  NSString *ssid;//wifi名称
@property (nonatomic ,strong) NSString *bssid;//wifi标识符
@property (nonatomic ) double signalStrength;//信号强度


+ (NetworkListModel *)setUpModelWithDictionary:(NSDictionary *)dictionary;



@end
